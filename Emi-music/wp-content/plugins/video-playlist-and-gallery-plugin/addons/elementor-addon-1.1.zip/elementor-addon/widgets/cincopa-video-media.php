<?php
class Elementor_Cincopa_Video_Media extends \Elementor\Widget_Base {

	public function __construct($data = [], $args = null) {
		parent::__construct($data, $args);

		
	 }
  
	 public function get_script_depends() {
		 return [ 'cincopa-script' ];
	 }

	public function get_name() {
		return 'cincopa_video_media';
	}

	public function get_title() {
		return esc_html__( 'Cincopa', 'elementor-addon' );
	}

	public function get_icon() {
		return 'eicon-video-playlist';
	}

	public function get_categories() {
		return [ 'general' ];
	}

	public function get_keywords() {
		return [ 'cincopa', 'video', 'media' ];
	}

	public function get_custom_help_url() {
		return 'https://www.cincopa.com/help/how-to-use-cincopa-elementor-addon-with-wordpress-elementor-builder/';
	}
	
	protected function register_controls() {
		$token = get_site_option('cincopa_cp_mt_api_token');

		if (!$token) {
			$token = get_user_meta(get_current_user_id(), 'cincopa_cp_mt_api_token', true);
		}
		// Content Tab Start
		
		if(function_exists('cincopa_mp_mt_get_authorize_url')){
			if($token){
				$this->start_controls_section(
					'cincopa-gallery-block',
					[
						'label' => esc_html__( 'Cincopa', 'elementor-addon' ),
						'tab' => \Elementor\Controls_Manager::TAB_CONTENT,
					]
				);	
				$this->add_control(
					'insert_cincopa',
					[
						'type' => \Elementor\Controls_Manager::BUTTON,
						'separator' => 'none',
						'show_label' => false,
						'button_type' => 'default',
						'text' => esc_html__( 'Insert from Cincopa', 'plugin-name' ),
					]
				);
				$this->add_control(
					'cincopa_gallery_title',
					[
						'label' => esc_html__( 'Insert short code', 'elementor-addon' ),
						'type' => \Elementor\Controls_Manager::HEADING,
						'default' => esc_html__( '', 'elementor-addon' ),
					]
				);
				$this->add_control(
					'cincopa_gallery_fid',
					[
						'label' => esc_html__( 'Media/Gallery RID', 'elementor-addon' ),
						'type' => \Elementor\Controls_Manager::TEXTAREA,
						'default' => esc_html__( '', 'elementor-addon' ),
					]
				);
				
			}else{
				$this->start_controls_section(
					'cincopa-gallery-block',
					[
						'label' => esc_html__( 'Cincopa', 'elementor-addon' ),
						'tab' => \Elementor\Controls_Manager::TAB_CONTENT,
					]
				);	
				
				$this->add_control(
					'login_cincopa',
					[
						'type' => \Elementor\Controls_Manager::BUTTON,
						'separator' => 'none',
						'show_label' => false,
						'button_type' => 'success',
						'text' => esc_html__( 'Connect', 'plugin-name' ),
					]
				);
			}
		}else{
			$this->start_controls_section(
				'not_available_settings_cincopa',
				[
					'label' => esc_html__( 'Cincopa message', 'plugin-name' ),
					'tab' => \Elementor\Controls_Manager::TAB_CONTENT,
				]
			);
	 
			$this->add_control(
				'not_available_message_cincopa',
				[
					'label' => esc_html__( 'Please install the plugin "Cincopa video and media plug-in".', 'plugin-name' ),
					'type' => \Elementor\Controls_Manager::HEADING,
					'separator' => 'before',
				]
			);
		}
		
		$this->end_controls_section();

		// Content Tab End
	}

	protected function render() {
			$settings = $this->get_settings_for_display();
			$fid = trim($settings['cincopa_gallery_fid']);
			$uni =  str_replace(['@', '!'], '_', $fid);

			if(function_exists('cincopa_mp_mt_get_authorize_url')){
		
			if($fid){
			?>	
				<div class="cincopa-video-media">
					<div id="cp_widget_<?php echo $uni; ?>"><img src="//www.cincopa.com/media-platform/runtime/loading.gif" style="border:0;" alt="Cincopa Elementor Addon" /></div>
					<script src="//www.cincopa.com/media-platform/runtime/libasync.js" type="text/javascript"></script>
					<script type="text/javascript">
						cp_load_widget('<?php echo $fid; ?>', "cp_widget_<?php echo $uni; ?>");
					</script>
				</div>				
			<?php
			}
		}
	}

	protected function content_template() {
		$random = generateRandomString(10);

		if(function_exists('cincopa_mp_mt_get_authorize_url')){
		?>	
		
		<div class="cincopa-video-media">
			<div id="cp_widget_<?php echo $random; ?>"><img src="//www.cincopa.com/media-platform/runtime/loading.gif" style="border:0;" alt="Cincopa Elementor Addon" /></div>			
			<script type='text/javascript'>
				cp_load_widget('{{{settings.cincopa_gallery_fid}}}', 'cp_widget_<?php echo $random; ?>');
			</script>
			<script src='https://www.cincopa.com/media-platform/runtime/libasync.js' type='text/javascript'></script>
		</div>	
		
		<?php
		}
	}
}

function generateRandomString($length = 25) {
    $characters = '0123456789abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ';
    $charactersLength = strlen($characters);
    $randomString = '';
    for ($i = 0; $i < $length; $i++) {
        $randomString .= $characters[rand(0, $charactersLength - 1)];
    }
    return $randomString;
}