<?php
/**
 * Plugin Name: Elementor Addon - Cincopa video and media plugin
 * Description: Post video players, slideshow albums, photo galleries and music / podcast playlist.
 * Version:     1.1
 * Author:      Cincopa
 * Author URI:  https://developers.elementor.com/
 */

function register_cincopa_video_media( $widgets_manager ) {

	require_once( __DIR__ . '/widgets/cincopa-video-media.php' );

	$widgets_manager->register( new \Elementor_Cincopa_Video_Media() );

	if(function_exists('cincopa_mp_mt_get_authorize_url')){

		wp_register_script( 'cincopa-script', 'https://www.cincopa.com/media-platform/runtime/libasync.js', false, '1.1', false );	
		
		$token = get_site_option('cincopa_cp_mt_api_token');	

		if (!$token) {
			$token = get_user_meta(get_current_user_id(), 'cincopa_cp_mt_api_token', true);
		}	
		wp_localize_script(
			'cincopa-script',
			'cincopa_cp_mt_options',
			array(
				'api_token' => $token,
				'site_url' => get_site_url(),
				'authorize_url' => cincopa_mp_mt_get_authorize_url(),
				'wp_elementor_build' => strpos($_SERVER['HTTP_HOST'].$_SERVER['REQUEST_URI'], 'action=elementor')
			)
		);
	}
}
add_action( 'elementor/widgets/register', 'register_cincopa_video_media' );