<?php

class CincopaElement extends OxyEl {

    function init() {
        
    }

    function afterInit() {
        $this->removeApplyParamsButton();
    }

    function name() {
        return 'Cincopa';
    }
    
    function slug() {
        return "cincopa";
    }

    function icon() {
        return 'https://wwwcdn.cincopa.com/_cms/wordpress/images/cincopa-logo-small.png';
    }

    function button_place() {
        
    }

    function button_priority() {

    }

    
    function render($options, $defaults, $content) {
        $fid = $options['fid'];
        $uni =  str_replace(['@', '!'], '_', $fid);
        ?>
        <div class="oxygen-cincopa-gallery">
				<div id="cp_widget_<?php echo $uni; ?>"><img src="//www.cincopa.com/media-platform/runtime/loading.gif" style="border:0;" alt="Cincopa Oxygen Addon" /></div>
				<script src="https://www.cincopa.com/media-platform/runtime/libasync.js" type="text/javascript"></script>
				<script type="text/javascript">
					cp_load_widget('<?php echo $fid; ?>', "cp_widget_<?php echo $uni; ?>");
				</script>
			</div>
        <?php
    }

    function controls() {

        $token = get_site_option('cincopa_cp_mt_api_token');

		if (!$token) {
			$token = get_user_meta(get_current_user_id(), 'cincopa_cp_mt_api_token', true);
		}
        if(function_exists('cincopa_mp_mt_get_authorize_url')){
            if($token){

                $fid_control = $this->addOptionControl(
                    array(
                        "type" => 'textfield',
                        "name" => 'Gallery FID',
                        "slug" => 'fid'
                    )
                );

                $fid_control->rebuildElementOnChange();

                $this->addOptionControl(
                    array(
                        "type" => 'buttons-list',
                        "name" => 'Insert from Cincopa',
                        "slug" => 'insert_btn'
                    )
                );
            }else{
                $this->addOptionControl(
                    array(
                        "type" => 'buttons-list',
                        "name" => 'Login to Cincopa',
                        "slug" => 'login_btn'
                    )
                );
            }
        }else{
            $this->addOptionControl(
                array(
                    "type" => 'buttons-list',
                    "name" => 'Please install the plugin "Cincopa video and media plug-in".',
                    "slug" => 'not_available_msg'
                )
            );
        }

    }

    function defaultCSS() {

        return file_get_contents(__DIR__.'/'.basename(__FILE__, '.php').'.css');
 
    }
    
}

new CincopaElement();
