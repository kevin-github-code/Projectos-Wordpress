<?php

/*
Plugin Name: Oxygen Addon - Cincopa video and media plugin
Author: Cincopa
Author URI: https://cincopa.com
Description: Post video players, slideshow albums, photo galleries and music / podcast playlist.
Version: 1.0
*/

add_action('plugins_loaded', 'cincopa_oxygen_elements_init');

function cincopa_oxygen_elements_init()
{

    if (!class_exists('OxygenElement')) {
        return;
    }

    foreach ( glob(plugin_dir_path(__FILE__) . "elements/*.php" ) as $filename)
    {
        include $filename;
    }
    
    $current_url = $_SERVER['HTTP_HOST'].$_SERVER['REQUEST_URI'];
    $oxygen_editor_active = strpos($current_url, 'ct_builder=');

    if($oxygen_editor_active){
        wp_enqueue_script( 'cincopa-libasync-oxygen', 'https://www.cincopa.com/media-platform/runtime/libasync.js', false, '1.0', false );
        wp_enqueue_script('cincopa-script-oxygen', plugins_url('video-playlist-and-gallery-plugin/js.cincopa.js'), array('jquery'), '1.0');
        wp_enqueue_style( 'cincopa-style', plugins_url('video-playlist-and-gallery-plugin/css.cincopa.css'), false, '1.0', 'all');

        if(function_exists('cincopa_mp_mt_get_authorize_url')){

            $token = get_site_option('cincopa_cp_mt_api_token');	

            if (!$token) {
                $token = get_user_meta(get_current_user_id(), 'cincopa_cp_mt_api_token', true);
            }	
            wp_localize_script(
                'cincopa-script-oxygen',
                'cincopa_cp_mt_options',
                array(
                    'api_token' => $token,
                    'site_url' => get_site_url(),
                    'authorize_url' => cincopa_mp_mt_get_authorize_url(),
                    'editor' => 'oxygen'
                )
            );
        }
    }
}
